from flask import Blueprint, render_template

bp = Blueprint('user', __name__)

@bp.route('/', defaults={'page': 'homepage'})

@bp.route('/simon')
def simon_index():
    return render_template('simon.html')


@bp.route('/trenton')
def trenton_index():
    return render_template('trenton.html')


@bp.route('/sean')
def sean_index():
    return render_template('sean.html')


@bp.route('/jermaine')
def jermaine_index():
    return render_template('jermaine.html')

@bp.route('/weather')
def weather_index():
    return render_template('weather.html')

@bp.route('/predict')
def prediction():
    return render_template('prediction.html')