from flask import Flask, escape, request, render_template
from user import bp
import pandas as pd
import joblib
import sklearn

application = Flask(__name__)
application.register_blueprint(bp)

@application.route('/')
def homepage():
    return render_template('base2.html')

#------ML Commands----#
def preprocessDataAndPredict(mountain, ocean, month, prcp_days_tRay, temp_max_normalRay, temp_min_normalRay, snow_daysRay, cloudsRay, dew, heat, wind):
    # keep all inputs in array
    data = [mountain, ocean, month, prcp_days_tRay, temp_max_normalRay, temp_min_normalRay, snow_daysRay, cloudsRay, dew, heat, wind]

    # Create Data Frame
    data = pd.DataFrame({ 'Mountains Nearby': [mountain],
                          'Ocean Nearby': [ocean],
                        'Month': [month],
                         'Freq. of Rain': [prcp_days_tRay],
                        'temp_max_normalRay': [temp_max_normalRay],
                         'temp_min_normalRay': [temp_min_normalRay],
                         'Snow_days': [snow_daysRay],
                         'Cloudy_days': [cloudsRay],
                          'Dew': [dew],
                          'Heat': [heat],
                          'Wind': [wind]
                         })

    # open file for data
    file = open("finalModel.pkl", "rb")

    # loading trained model based on file location (file = location of data file)
    trained_model = joblib.load(file)


    prediction = trained_model.predict(data)

    print(prediction[0])
    return prediction[0]

# Connection both the py data and form data from user to output predictions
@application.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == "POST":
        #Some Default values needed for model
        mountain = 1
        ocean = 1
        dew = 1
        heat = 1
        wind = 1

        # get form data
        month = request.form.get('month')
        prcp_days_tRay = request.form.get('prcp_days_tRay')
        temp_max_normalRay = request.form.get('temp_max_normalRay')
        temp_min_normalRay = request.form.get('temp_min_normalRay')
        snow_daysRay = request.form.get('snow_daysRay')
        cloudsRay = request.form.get('cloudsRay')

        # call preprocessDataAndPredict and pass inputs
        #try:
        prediction = preprocessDataAndPredict(mountain, ocean, month, prcp_days_tRay, temp_max_normalRay, temp_min_normalRay, snow_daysRay, cloudsRay, dew, heat, wind)
            # pass prediction to template
        return render_template('predict.html', prediction=prediction)

        #except ValueError:
        #    return "Please Enter valid values"

        #pass
    pass

if __name__ == "__main__":
    application.run(host='localhost', port=5000, debug=True)